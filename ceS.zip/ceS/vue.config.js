module.exports = {
  // 是否开启eslint
  lintOnSave: false,

  
   }


