<script setup>
import {
  ElSelect,
  ElOption,
  ElButton,
  ElTooltip,
  ElLoading,
  // 库位信息
  ElNotification,
  ElMessage,
  ElMessageBox,
  TabsPaneContext,
} from "element-plus";

import { ref, getCurrentInstance, h, reactive, onMounted } from "vue";

import axios from "axios";

let rowOne = reactive([]);
let rowTwo = reactive([]);

//dialog
const dialogTableVisible = ref(false);
const dialogFormVisible = ref(false);
const formLabelWidth = "140px";

const form = reactive({
  name: "",
  region: "",
  date1: "",
  date2: "",
  delivery: false,
  type: [],
  resource: "",
  desc: "",
});

const gridData = [
  {
    date: "2016-05-02",
    name: "John Smith",
    address: "No.1518,  Jinshajiang Road, Putuo District",
  },
  {
    date: "2016-05-04",
    name: "John Smith",
    address: "No.1518,  Jinshajiang Road, Putuo District",
  },
  {
    date: "2016-05-01",
    name: "John Smith",
    address: "No.1518,  Jinshajiang Road, Putuo District",
  },
  {
    date: "2016-05-03",
    name: "John Smith",
    address: "No.1518,  Jinshajiang Road, Putuo District",
  },
];
// 弹窗-库位信息
// const openVn = () => {
//   ElMessage({
//     message: h("p", null, [
//       h("p", { style: "color: teal" }, "位置:LH-1-1-1-2 "),
//       h("p", { style: "color: teal" }, "在库料箱: LX-001"),

//       h("p", { style: "color: white" }, "      、  "),
//       h("p", { style: "color: teal" }, "物料编码: A0101"),
//       h("p", { style: "color: teal" }, "物料名称: 测试物料1"),
//       h("p", { style: "color: teal" }, "数量:11"),
//       h("p", { style: "color: black" }, "-------------------"),

//       h("p", { style: "color: teal" }, "物料编码: B0101"),
//       h("p", { style: "color: teal" }, "物料名称: 测试物料2"),
//       h("p", { style: "color: teal" }, "数量:22"),
//     ]),
//     duration: 100000,
//     center: true,
//     "show-close": true,
//     offset: 200,
//   });
// };

async function getList() {
  let loading = ElLoading.service({
    lock: true,
    text: "加载中",
    background: "rgba(0, 0, 0, 0.8)",
  });
  let data = await axios({
    method: "post",
    url: "http://39.170.118.36:8001/api/mingdao/storagePosition",
    // url: "http://39.170.118.36:8001/api/mingdao/positionDetail",
    data: {
      appKey: "e4efec6d23bfe395",
      sign: "YTdmYjUyMWMwMGY0ZTVlYjEwMDQ5ODgzOTI4YmUxMjQxN2QxMWQyMTE4MWNkYzlkMzNhMGJiZWYxY2Y1NTNhMQ==",
      worksheetId: "605c1d287a2b4eb1fde6d410",
      viewId: "605c1d2a7a2b4eb1fde6d4be",
      pageSize: 999,
      pageIndex: 1,
    },
  });
  console.log(data);
  // debugger
  let arr = data.data.data.rows;
  //不同库区的库位列数
  //value.value
  let rowO = optionStatus[value.value].rowOne;
  let rowT = optionStatus[value.value].rowTwo;
  let rowOne_ = arr
    .filter((it) => {
      return (
        it.row == rowO &&
        /^CL/.test(it.positionCode) &&
        it.story == storyValue.value
      );
    })
    .sort((a, b) => {
      return a.column - b.column;
    });
  let rowTwo_ = arr
    .filter((it) => {
      return (
        it.row == rowT &&
        /^CL/.test(it.positionCode) &&
        it.story == storyValue.value
      );
    })
    .sort((a, b) => {
      return a.column - b.column;
    });

  rowOne_.forEach((it, idx) => {
    rowOne.splice(idx, 1, it);
  });
  rowTwo_.forEach((it, idx) => {
    rowTwo.splice(idx, 1, it);
  });
  //渲染加载延时设置
  setTimeout(() => {
    loading.close();
  }, 500);
}
//会先判断是否启用，没启用的库位（否），将会锁定，更换视图，优先级高于所有状态，直接return跳出
function checkStatus(sta) {
  let result = "";

  if (sta.locked === "否") {
    return "locked";
  }

  if (sta.positionStatus === "无货") {
    result = "empty";
  } else if (sta.positionStatus === "料框占用") {
    result = "emptyTray";
  } else if (sta.positionStatus === "有货") {
    result = "occupy";
  } else if (sta.positionStatus === "作业中") {
    result = "working";
  }
  return result;
}

function addEmpty() {
  let loading = ElLoading.service({
    lock: true,
    text: "加载库位中",
    background: "rgba(0, 0, 0, 0.8)",
  });

  setTimeout(() => {
    loading.close();
  }, 1000);

  storyValue.value = "1";
  // 区位切换，重置框位数为0
  rowOne.length = 0;
  rowTwo.length = 0;
  //注释掉，换区换多一列，不换区从第二格开始
  // // 根据每个区，生成不同数量的空框位,需要给value-1?
  rowOne.push(...new Array(optionStatus[value.value].count).fill({}));
  rowTwo.push(...new Array(optionStatus[value.value].count).fill({}));
  getList();
}

//下拉框
let options = ref([
  {
    value: "0",
    label: "成品区-长料成品1区",
  },
  {
    value: "1",
    label: "成品区-长料成品2区",
  },
  {
    value: "2",
    label: "成品区-短料成品1区",
  },
  {
    value: "3",
    label: "空料区-长料空框1区",
  },
  {
    value: "4",
    label: "空料区-短料空框1区",
  },
]);

let optionStatus = reactive([
  {
    // 长料框C成品一区56排，12行
    count: 12,
    rowOne: 5,
    rowTwo: 6,
  },
  {
    //长料成品2区
    count: 11,
    rowOne: 3,
    rowTwo: 4,
  },
  {
    // 短料成品一区
    count: 10,
    rowOne: 9,
    rowTwo: 10,
  },
  {
    // 长料空框
    count: 11,
    rowOne: 1,
    rowTwo: 2,
  },
  {
    // 短料空框
    count: 8,
    rowOne: 7,
    rowTwo: 8,
  },
]);

//默认第一排
let value = ref("0");

// 选择层数
let stories = ref([
  {
    value: "1",
    label: "一层",
  },
  {
    value: "2",
    label: "二层",
  },
]);

let currentView = ref(0);
function viewSwitch(value) {
  currentView.value = value;
}

let pai = ref(1);
let paiOptions = ref([
  {
    value: 1,
    label: "长空1区-1排",
  },
  {
    value: 2,
    label: "长空1区-2排",
  },
  {
    value: 3,
    label: "长成2区-3排",
  },
  {
    value: 4,
    label: "长成2区-4排",
  },
  {
    value: 5,
    label: "长成1区-5排",
  },
  {
    value: 6,
    label: "长成1区-6排",
  },
  {
    value: 7,
    label: "短空1区-7排",
  },
  {
    value: 8,
    label: "短空1区-8排",
  },
  {
    value: 9,
    label: "短层1区-9排",
  },
  {
    value: 10,
    label: "短层1区-10排",
  },
]);

//默认第一列，记得是挂载上去，就会默认先加载一次
let storyValue = ref("0");
onMounted(() => {
  // 默认请求第一行
  addEmpty();
  storyValue.value = "1";
});
</script>


<template>
  <div class="main">
    <!-- views switch buttons-->
    <!-- 俯视正式角度切换 -->
    <span class="viewSwitch">
      <button
        :class="['viewsBtn', currentView === 0 ? 'active' : '']"
        @click="viewSwitch(0)"
      >
        俯视
      </button>
      <button
        :class="['viewsBtn', currentView === 1 ? 'active' : '']"
        @click="viewSwitch(1)"
      >
        正视
      </button>
      <button
        :class="['viewsBtn', currentView === 2 ? 'active' : '']"
        @click="viewSwitch(2)"
      >
        侧视
      </button>
    </span>
    <br /><br />

    <!-- 选择库位 -->
    <div class="selectPart" v-show="currentView === 0">
      <!-- 选区 -->
      <el-select v-model="value" placeholder="区域" @change="addEmpty">
        <el-option
          v-for="item in options"
          :key="item.value"
          :label="item.label"
          :value="item.value"
        >
        </el-option>
      </el-select>
      <!-- 选层 -->
      <el-select
        class="story"
        v-model="storyValue"
        placeholder="层"
        @change="getList"
        :disabled="!value"
      >
        <el-option
          v-for="item in stories"
          :key="item.value"
          :label="item.label"
          :value="item.value"
        >
        </el-option>
      </el-select>
      <!-- 根据是否选区，来判断是否可以刷新 -->
      <el-button
        :disabled="!value"
        class="request"
        type="primary"
        @click="getList"
        plain
        >刷新</el-button
      >

      <!-- 弹窗 库位信息1-->
      <!-- <el-button plain @click="open"> 库位信息1 </el-button> -->
      <el-button :plain="true" @click="openVn">库位信息</el-button>
    </div>
    <div class="selectPart" v-show="currentView === 1">
      <!-- 选区 -->
      <el-select v-model="pai" placeholder="排" @change="addEmpty">
        <el-option
          v-for="item in paiOptions"
          :key="item.value"
          :label="item.label"
          :value="item.value"
        >
        </el-option>
      </el-select>

      <!-- 根据是否选区，来判断是否可以刷新 -->
      <el-button
        :disabled="!value"
        class="request"
        type="primary"
        @click="getList"
        plain
        >刷新</el-button
      >

      <!-- 弹窗 库位信息1-->
      <!-- <el-button plain @click="open"> 库位信息1 </el-button> -->
      <el-button :plain="true" @click="openVn">库位信息</el-button>
    </div>
    <div class="selectPart" v-show="currentView === 2">
      <!-- 选区 -->
      <el-select v-model="value" placeholder="区域" @change="addEmpty">
        <el-option
          v-for="item in options"
          :key="item.value"
          :label="item.label"
          :value="item.value"
        >
        </el-option>
      </el-select>
      <!-- 选层 -->
      <el-select
        class="story"
        v-model="storyValue"
        placeholder="层"
        @change="getList"
        :disabled="!value"
      >
        <el-option
          v-for="item in stories"
          :key="item.value"
          :label="item.label"
          :value="item.value"
        >
        </el-option>
      </el-select>
      <!-- 根据是否选区，来判断是否可以刷新 -->
      <el-button
        :disabled="!value"
        class="request"
        type="primary"
        @click="getList"
        plain
        >刷新</el-button
      >

      <!-- 弹窗 库位信息1-->
      <!-- <el-button plain @click="open"> 库位信息1 </el-button> -->
      <el-button :plain="true" @click="openVn">库位信息</el-button>
    </div>

    <!-- <el-button :plain="true" @click="open">Show message</el-button> -->

    <!-- 库位区 -->
    <!-- 顶部 -->
    <div id="topShadow"></div>
    <!-- 俯视图 -->
    <div class="boxesContainer" v-show="currentView === 0">
      <div class="columnNo">
        <div class="rowNumbers box" v-for="(item, idx) in rowOne" :key="idx">
          {{ idx + 1 }}
        </div>
      </div>
      <div class="rowOne">
        <div
          class="box"
          :class="['box', checkStatus(item)]"
          v-for="(item, idx) in rowTwo"
          @click="info"
          key="idx"
        >
          <!--  show-after="300" 加了show-after 处理移动过快产生的黑色小方块问题-->
          <el-tooltip
            :content="item.positionCode"
            v-if="item.positionCode"
            placement="top"
            show-after="300"
          >
            <el-button
              @click="openVn"
              style="opacity: 0; margin-left: -1px; width: 50px; height: 100%"
            ></el-button>
          </el-tooltip>
        </div>

        <!-- </el-tooltip> -->
      </div>
      <div class="rowTwo">
        <div
          class="box"
          :class="['box', checkStatus(item)]"
          v-for="(item, idx) in rowOne"
          @click="info"
          key="idx"
        >
          <!-- 框{{ idx + 1 }} -->
          <!-- v-if的bug需要修复 -->
          <!-- show-after修改了鼠标hover上去多久之后出现的时间，默认是0，修改为300，默认为0，频繁触发导致出现黑色方块 -->
          <!-- //库位信息 小黑条-->
          <el-tooltip
            :content="item.positionCode"
            v-if="item.positionCode"
            placement="bottom"
            show-after="300"
          >
            <el-button
              @click="openVn"
              style="opacity: 0; width: 50px; height: 100%"
            ></el-button>
          </el-tooltip>
        </div>
      </div>
      <div class="wrap">
        <div class="rowNo">
          <p>{{ optionStatus[value]?.rowTwo }}</p>
        </div>
        <div class="rowNo">
          <p>{{ optionStatus[value]?.rowOne }}</p>
        </div>
      </div>
      <div id="rightShadow"></div>
    </div>
    <!-- 正视图 -->
    <div class="boxesContainer" v-show="currentView === 1">
      <div class="columnNo">
        <div class="rowNumbers box" v-for="(item, idx) in rowOne" :key="idx">
          {{ idx + 1 }}
        </div>
      </div>
      <div class="rowOne">
        <div
          class="box"
          :class="['box', checkStatus(item)]"
          v-for="(item, idx) in rowTwo"
          @click="info"
          key="idx"
        >
          <el-tooltip
            :content="item.positionCode"
            v-if="item.positionCode"
            placement="top"
            show-after="300"
          >
            <el-button
              style="opacity: 0; margin-left: -1px; width: 50px; height: 100%"
            ></el-button>
          </el-tooltip>
        </div>

        <!-- </el-tooltip> -->
      </div>
      <div class="rowTwo">
        <div
          class="box"
          :class="['box', checkStatus(item)]"
          v-for="(item, idx) in rowOne"
          @click="info"
          key="idx"
        >
          <!-- 框{{ idx + 1 }} -->
          <!-- v-if的bug需要修复 -->
          <!-- show-after修改了鼠标hover上去多久之后出现的时间，默认是0，修改为300，默认为0，频繁触发导致出现黑色方块 -->
          <!-- //库位信息 小黑条-->
          <el-tooltip
            :content="item.positionCode"
            v-if="item.positionCode"
            placement="bottom"
            show-after="300"
          >
            <el-button
              style="opacity: 0; width: 50px; height: 100%"
            ></el-button>
          </el-tooltip>
        </div>
      </div>

      <div class="wrap">
        <div class="rowNo">
          <p>2</p>
        </div>
        <div class="rowNo">
          <p>1</p>
        </div>
      </div>
      <div id="rightShadow"></div>
    </div>
    <!-- 侧视图-->
    <div class="boxesContainer" v-show="currentView === 2">
      <div class="columnNo">
        <div class="rowNumbers box" v-for="(item, idx) in rowOne" :key="idx">
          {{ idx + 1 }}
        </div>
      </div>
      <div class="rowOne">
        <div
          class="box"
          :class="['box', checkStatus(item)]"
          v-for="(item, idx) in rowTwo"
          @click="info"
          key="idx"
        >
          <el-tooltip
            :content="item.positionCode"
            v-if="item.positionCode"
            placement="top"
            show-after="300"
          >
            <el-button
              style="opacity: 0; margin-left: -1px; width: 50px; height: 100%"
            ></el-button>
          </el-tooltip>
        </div>

        <!-- </el-tooltip> -->
      </div>
      <div class="rowTwo">
        <div
          class="box"
          :class="['box', checkStatus(item)]"
          v-for="(item, idx) in rowOne"
          @click="info"
          key="idx"
        >
          <!-- 框{{ idx + 1 }} -->
          <!-- v-if的bug需要修复 -->
          <!-- show-after修改了鼠标hover上去多久之后出现的时间，默认是0，修改为300，默认为0，频繁触发导致出现黑色方块 -->
          <!-- //库位信息 小黑条-->
          <el-tooltip
            :content="item.positionCode"
            v-if="item.positionCode"
            placement="bottom"
            show-after="300"
          >
            <el-button
              style="opacity: 0; width: 50px; height: 100%"
            ></el-button>
          </el-tooltip>
        </div>
      </div>
      <div class="wrap">
        <div class="rowNo">
          <p>{{ optionStatus[value]?.rowTwo }}</p>
        </div>
        <div class="rowNo">
          <p>{{ optionStatus[value]?.rowOne }}</p>
        </div>
      </div>
      <div id="rightShadow"></div>
    </div>
    <!-- 状态展示 -->
    <br />
    <div class="displayContainer">
      <div class="displayBox">
        <div class="empty dBoxes"></div>
        <p>无货</p>
      </div>

      <div class="displayBox">
        <div class="occupy dBoxes"></div>
        <p>有货</p>
      </div>

      <div class="displayBox">
        <div class="emptyTray dBoxes"></div>
        <p>料框占用</p>
      </div>

      <div class="displayBox">
        <div class="working dBoxes"></div>
        <p>作业中</p>
      </div>

      <div class="displayBox">
        <div class="locked dBoxes"></div>
        <p>锁定</p>
      </div>
    </div>

    <br />
  </div>

  <el-button text @click="dialogTableVisible = true"
    >open a Table nested Dialog</el-button
  >

  <el-dialog v-model="dialogTableVisible" title="Shipping address">
    <el-table :data="gridData">
      <el-table-column property="date" label="Date" width="150" />
      <el-table-column property="name" label="Name" width="200" />
      <el-table-column property="address" label="Address" />
    </el-table>
  </el-dialog>

  <!-- Form -->
  <el-button text @click="dialogFormVisible = true"
    >open a Form nested Dialog</el-button
  >

  <el-dialog v-model="dialogFormVisible" title="Shipping address">
    <el-form :model="form">
      <el-form-item label="Promotion name" :label-width="formLabelWidth">
        <el-input v-model="form.name" autocomplete="off" />
      </el-form-item>
      <el-form-item label="Zones" :label-width="formLabelWidth">
        <el-select v-model="form.region" placeholder="Please select a zone">
          <el-option label="Zone No.1" value="shanghai" />
          <el-option label="Zone No.2" value="beijing" />
        </el-select>
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button @click="dialogFormVisible = false">Cancel</el-button>
        <el-button type="primary" @click="dialogFormVisible = false"
          >Confirm</el-button
        >
      </span>
    </template>
  </el-dialog>
</template>

<style lang="scss">
.el-message {
  --el-message-min-width: 320px !important;
  // --el-message--info: green !important;

  // --el-message-min-height:280px  !important;
  // --el-message-padding:25px 25px 25px 40px !important;
}

label {
  width: 400px;
  height: 30px;
  float: left;
  text-align: center;
  line-height: 30px;
  border-right: 1px solid brown;
  border-bottom: 1px solid brown;
}

label div {
  width: 100%;
  height: 100px;
  position: absolute;
  left: 0;
  top: 31px;
  background: #b3d8ff;
  display: none;
}

label input {
  width: 0;
}

input:checked + div {
  display: block;
}
</style>



<style lang="scss" scoped>
.viewsBtn {
  width: 100px;
  height: 40px;
  margin-left: 5px;
  color: #409efe;
  box-sizing: border-box;
  border-color: #b3d8ff;
  border-radius: 10px;
  background-color: #ffffff;
}
.viewsBtn.active {
  // background: rgb(130, 235, 130);
  background: rgb(130, 235, 130);
  color: black;
}

.main {
  // border: 1px solid blue;
  min-width: 990px;
  max-width: 1000px;
  padding: 40px;
  height: 100px;
  padding: 0.8% 0 0 0;
  margin: 0 auto;

  // .viewSwitch {
  //   padding-top: 100px;
  // }

  .selectPart {
    min-width: 800px;

    .story {
      margin: 0px 10% 0 20%;
    }

    .request {
      margin-left: 20px;
    }
  }

  #topShadow {
    min-width: 800px;
    margin-top: 30px;
    position: relative;
    background-color: rgb(214, 207, 207);
    width: 94.1%;
    height: 31px;
    margin-left: 1%;
    padding-top: 1px;
    transform: skew(-35deg);
    z-index: 999;
  }

  #rightShadow {
    background-color: #b6aeae;
    width: 35px;
    height: 153px;
    transform: rotate(-55deg) skew(-55deg);
    position: absolute;
    top: 14.6%;
    left: 99.8%;
    z-index: 1;
  }

  .boxesContainer {
    display: inline-block;
    position: relative;
    z-index: 1;
    color: gray;
    // background-color: rgba(209, 206, 206, 0.938);
    border: 6px solid rgb(182, 181, 181);
    border-right: 6px solid rgb(182, 174, 174);
    border-top: 6px solid rgb(214, 207, 207);
    border-left: 6px solid rgb(214, 207, 207);
    border-bottom: 6px solid rgb(214, 207, 207);
    // border-top: 10px solid red;
    border-radius: 3px;

    width: 90%;
    height: 220px;
    margin-top: -4px;
    padding: 20px 0 20px 30px;
    position: relative;
    min-width: 800px;

    .columnNo,
    .rowOne,
    .rowTwo {
      margin-top: 30px;
      padding: 0 20px 0 20px;
      // border: 1px solid green;
      display: flex;
      flex-direction: row-reverse;
      justify-content: space-around;

      // 未渲染
      .box {
        width: 50px;
        height: 50px;
        border: 1px solid lightgray;
        border-radius: 10px;
        // margin: 20px 0 20px 0;
        // background-image: url(../assets/lary1.jpg);
        background-size: 100%;
        background-repeat: no-repeat;
        font-size: 6%;

        &.empty {
          background-image: url(../assets/empty.svg);
        }

        &.emptyTray {
          background-image: url(../assets/emptyTray.svg);
        }

        &.occupy {
          background-image: url(../assets/occupy.svg);
        }

        &.locked {
          background-image: url(../assets/locked.svg);
        }

        &.working {
          background-image: url(../assets/working.svg);
        }
      }

      .rowNumbers {
        border: none;
        text-align: center;
        height: 20px;
      }
    }

    .columnNo {
      margin-top: 0px;
    }

    .wrap {
      position: absolute;
      font-size: 12px;
      left: 0px;
      top: 55px;

      .rowNo {
        width: 50px;
        line-height: 50px;
        text-align: center;
        margin: 0 0 30px 0;
      }
    }
  }

  .displayContainer {
    width: 94%;
    margin-top: 20px;

    display: flex;
    flex-direction: row;
    justify-content: space-around;
    min-width: 800px;

    .displayBox {
      width: 70px;
      height: 100px;
      // border: 2px solid red;
      text-align: center;
      left: 50%;

      //3D新增
      %test {
        position: absolute;
        content: "";
        transition: all 0.5s;
        transition: all 0.5s;
      }

      .dBoxes {
        margin: 40px -10px 0 25px;

        width: 70px;
        height: 70px;
        background-repeat: no-repeat;
        background-size: 100%;
        transform: translate(-50%, -50%);
        text-decoration: none;
        font-size: 4vw;
        transition: all 0.5s;
        background-color: #3498db;

        //3D新增-下方
        &::before {
          @extend %test;
          bottom: -10px;
          height: 10px;
          width: 100%;
          left: 5px;
          transform: skewX(45deg);
          background-color: darken(#3498db, 26%);
        }

        // 3D右侧
        &::after {
          @extend %test;
          right: -10px;
          height: 100%;
          width: 10px;
          bottom: -5px;
          transform: skewY(45deg);
          background-color: darken(#3498db, 16%);
        }
      }

      .empty {
        background-image: url(../assets/empty.svg);
      }

      .emptyTray {
        background-image: url(../assets/emptyTray.svg);
      }

      .occupy {
        background-image: url(../assets/occupy.svg);
      }

      .locked {
        background-image: url(../assets/locked.svg);
      }

      .working {
        background-image: url(../assets/working.svg);
      }
    }
  }
}
</style>
